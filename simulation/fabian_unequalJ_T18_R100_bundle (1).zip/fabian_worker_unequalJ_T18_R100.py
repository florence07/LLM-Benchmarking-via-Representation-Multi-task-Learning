#!/usr/bin/env python3
"""One-Slurm-array-task worker for the unequal-J Proposed-CV simulation.

Each task runs exactly one (h, replication) dataset.  With the default
10 h values and R=100 there are 1000 array tasks.  Replication r uses the
same data seed for every h, preserving the paired simulation design.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from simulation_cv_lambda_scaled_T18_R100 import run_three_estimator_comparison


# ---------------------------------------------------------------------------
# Simulation configuration: kept identical to the uploaded serial program,
# except that one Slurm array task handles one (h, replication) pair.
# ---------------------------------------------------------------------------
N_VALUES = [100]
T_VALUES = [18]
J_VECTOR_VALUES = [[50, 60, 70, 80, 90, 100] * 3]

H_VALUES = [0, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5]
C_LAMBDA_VALUES = [i * 0.1 for i in range(1, 21)]

R = 100
CV_FOLDS = 5
CV_JOBS = 8
BASE_SEED = 20260819
PROPOSED_THETA_PERTURBATION = 0.10

DATA_KWARGS = {
    "score_power": 1.0,
    "discrimination_low": 0.50,
    "discrimination_high": 1.50,
    "easiness_low": -1.00,
    "easiness_high": 1.00,
    "heterogeneity_structure": "random_alpha",
    "majority_proportion": 0.60,
    "minimum_relative_angle": 0.35,
    "theta_bound": 4.0,
    "shuffle_ai_labels": True,
    "population_common_trait_max_iter": 5000,
    "population_common_trait_tolerance": 1e-13,
    # IMPORTANT: every independent h-task validates against the same full h grid.
    # This preserves the same accepted random template across h within a replication.
    "shared_h_values": tuple(H_VALUES),
}

PROPOSED_CV_FIT_KWARGS = {
    "theta_bound": 4.0,
    "a_bound": 4.0,
    "d_bound": 4.0,
    "learning_rate": 0.02,
    "learning_rate_decay_factor": 0.5,
    "learning_rate_decay_steps": 400,
    "max_iter": 4000,
    "tolerance": 1e-9,
    "verbose": False,
}

LOCAL_FIT_KWARGS = {
    "theta_bound": 4.0,
    "a_bound": 4.0,
    "d_bound": 4.0,
    "learning_rate": 0.02,
    "learning_rate_decay_factor": 0.5,
    "learning_rate_decay_steps": 500,
    "max_iter": 2000,
    "tolerance": 1e-9,
    "verbose": False,
}

GLOBAL_FIT_KWARGS = {
    "theta_bound": 4.0,
    "a_bound": 4.0,
    "d_bound": 4.0,
    "learning_rate": 0.02,
    "learning_rate_decay_factor": 0.5,
    "learning_rate_decay_steps": 500,
    "max_iter": 5000,
    "tolerance": 1e-12,
    "verbose": False,
}


TABLE_FILENAMES = {
    "raw": "simulation_raw_results.csv",
    "domains": "simulation_domain_results.csv",
    "cv_tuning": "simulation_cv_tuning_results.csv",
    "cv_folds": "simulation_cv_fold_results.csv",
}


def decode_task_id(task_id: int) -> tuple[int, int, float, int]:
    """Map task id to (h_index, repeat_index_zero_based, h, repeat_one_based)."""
    total_tasks = len(H_VALUES) * R
    if not 0 <= task_id < total_tasks:
        raise ValueError(f"task_id must be in [0, {total_tasks - 1}].")

    h_index = task_id // R
    repeat_index = task_id % R
    return h_index, repeat_index, H_VALUES[h_index], repeat_index + 1


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--task-id", type=int, required=True)
    parser.add_argument("--output-root", type=Path, default=Path("results_unequalJ_T18_R100"))
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print the task mapping and exit without fitting.",
    )
    args = parser.parse_args()

    h_index, repeat_index, h_value, repeat_number = decode_task_id(args.task_id)
    data_seed = BASE_SEED + repeat_index

    print(
        f"task_id={args.task_id}; h_index={h_index}; h={h_value}; "
        f"repeat={repeat_number}; seed={data_seed}; CV_JOBS={CV_JOBS}",
        flush=True,
    )
    if args.dry_run:
        return

    # R=1 here because this worker is exactly one Monte Carlo replication.
    # Passing BASE_SEED + repeat_index gives the same seed for a fixed repeat
    # at every h, exactly matching the paired design of the serial driver.
    results = run_three_estimator_comparison(
        N_values=N_VALUES,
        T_values=T_VALUES,
        J_vector_values=J_VECTOR_VALUES,
        h_values=[h_value],
        C_lambda_values=C_LAMBDA_VALUES,
        R=1,
        cv_folds=CV_FOLDS,
        cv_jobs=CV_JOBS,
        base_seed=data_seed,
        proposed_theta_perturbation=PROPOSED_THETA_PERTURBATION,
        data_kwargs=DATA_KWARGS,
        proposed_cv_fit_kwargs=PROPOSED_CV_FIT_KWARGS,
        local_fit_kwargs=LOCAL_FIT_KWARGS,
        global_fit_kwargs=GLOBAL_FIT_KWARGS,
        progress=True,
    )

    # The single-dataset driver labels its local h setting as setting_id=1 and
    # repeat=1.  Replace those with the global grid identifiers before saving,
    # so concatenation across Slurm tasks reproduces the full experiment table.
    setting_id = h_index + 1
    for table_name, frame in results.items():
        if frame.empty:
            continue
        if "setting_id" in frame.columns:
            frame.loc[:, "setting_id"] = setting_id
        if "repeat" in frame.columns:
            frame.loc[:, "repeat"] = repeat_number
        if "seed" in frame.columns:
            frame.loc[:, "seed"] = data_seed

    task_dir = args.output_root / f"task_{args.task_id:04d}"
    task_dir.mkdir(parents=True, exist_ok=True)

    # Save only primitive task-level tables.  The Monte Carlo summary must be
    # rebuilt after all replications are concatenated; a per-task R=1 summary
    # would have undefined standard deviations.
    for table_name, filename in TABLE_FILENAMES.items():
        results[table_name].to_csv(task_dir / filename, index=False)

    # Marker is written last, so the combine script can distinguish a complete
    # task from a partially written/preempted task directory.
    (task_dir / "DONE").write_text(
        f"task_id={args.task_id}\nh={h_value}\nrepeat={repeat_number}\nseed={data_seed}\n",
        encoding="utf-8",
    )
    print(f"completed task {args.task_id}: {task_dir}", flush=True)


if __name__ == "__main__":
    main()
