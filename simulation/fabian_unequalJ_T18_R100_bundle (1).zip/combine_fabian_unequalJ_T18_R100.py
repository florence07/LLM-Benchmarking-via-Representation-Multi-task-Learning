#!/usr/bin/env python3
"""Combine all completed unequal-J Fabian shards and rebuild the R-level summary."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import pandas as pd

from fabian_worker_unequalJ_T18_R100 import H_VALUES, R, TABLE_FILENAMES
from simulation_cv_lambda_scaled_T18_R100 import _build_comparison_summary


def _read_completed_task_dirs(root: Path) -> tuple[list[Path], list[int]]:
    expected = len(H_VALUES) * R
    completed: list[Path] = []
    missing: list[int] = []
    for task_id in range(expected):
        task_dir = root / f"task_{task_id:04d}"
        required = [task_dir / "DONE"] + [
            task_dir / filename for filename in TABLE_FILENAMES.values()
        ]
        if all(path.exists() for path in required):
            completed.append(task_dir)
        else:
            missing.append(task_id)
    return completed, missing


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, default=Path("results_unequalJ_T18_R100"))
    parser.add_argument("--output-dir", type=Path, default=Path("results_unequalJ_T18_R100/combined"))
    parser.add_argument(
        "--require-complete",
        action="store_true",
        help="Fail unless all expected array tasks are complete.",
    )
    args = parser.parse_args()

    completed, missing = _read_completed_task_dirs(args.input_root)
    expected = len(H_VALUES) * R
    print(f"Found {len(completed)} completed tasks out of {expected} expected.")
    if missing:
        preview = ", ".join(map(str, missing[:30]))
        suffix = " ..." if len(missing) > 30 else ""
        print(f"Missing/incomplete task IDs ({len(missing)}): {preview}{suffix}")
        if args.require_complete:
            raise SystemExit("Not all tasks are complete; refusing final combine.")
    if not completed:
        raise SystemExit("No completed task directories were found.")

    combined: dict[str, pd.DataFrame] = {}
    for table_name, filename in TABLE_FILENAMES.items():
        frames = [pd.read_csv(task_dir / filename) for task_dir in completed]
        combined[table_name] = pd.concat(frames, ignore_index=True)

    raw = combined["raw"].sort_values(
        ["setting_id", "repeat", "method"], na_position="last"
    ).reset_index(drop=True)
    domains = combined["domains"].sort_values(
        ["setting_id", "repeat", "method", "domain"], na_position="last"
    ).reset_index(drop=True)
    cv_tuning = combined["cv_tuning"].sort_values(
        ["setting_id", "repeat", "C_lambda"]
    ).reset_index(drop=True)
    cv_folds = combined["cv_folds"].sort_values(
        ["setting_id", "repeat", "fold", "C_lambda"]
    ).reset_index(drop=True)

    # Critical: recompute the Monte Carlo summary from the combined raw rows,
    # rather than averaging per-task summaries.
    summary = _build_comparison_summary(raw)

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True, exist_ok=False)

    outputs = {
        "summary": (summary, "simulation_summary.csv"),
        "raw": (raw, "simulation_raw_results.csv"),
        "domains": (domains, "simulation_domain_results.csv"),
        "cv_tuning": (cv_tuning, "simulation_cv_tuning_results.csv"),
        "cv_folds": (cv_folds, "simulation_cv_fold_results.csv"),
    }
    for name, (frame, filename) in outputs.items():
        path = args.output_dir / filename
        frame.to_csv(path, index=False)
        print(f"{name}: {path} ({len(frame)} rows)")

    # Small completion audit by h.  For a complete run each h should have R
    # unique repetitions and raw should contain exactly three methods per repeat.
    audit = (
        raw.groupby("h_target")
        .agg(
            repetitions=("repeat", "nunique"),
            raw_rows=("method", "size"),
        )
        .reset_index()
    )
    audit["expected_repetitions"] = R
    audit["expected_raw_rows"] = 3 * R
    audit_path = args.output_dir / "completion_audit.csv"
    audit.to_csv(audit_path, index=False)
    print(f"audit: {audit_path}")


if __name__ == "__main__":
    main()
