LSE Fabian — Unequal-J T=18, R=100
==================================

Setting
-------
N = 100
T = 18
J_t = [50,60,70,80,90,100] repeated 3 times
H_VALUES = [0, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5]
C_lambda = 0.1,0.2,...,2.0
R = 100
CV_FOLDS = 5
CV_JOBS = 8
BASE_SEED = 20260819

Total tasks
-----------
10 h values x 100 replications = 1000 Slurm array tasks

Resources
---------
#SBATCH --array=0-999%25
#SBATCH --cpus-per-task=8
#SBATCH --mem=16G

Suggested directory
-------------------
~/AI_benchmarking_0822_T18

Run
---
cd ~
mkdir -p AI_benchmarking_0822_T18
cd AI_benchmarking_0822_T18

unzip fabian_unequalJ_T18_R100_bundle.zip

~/AI_measurement_simulation_0817/.venv/bin/python -m py_compile   simulation_cv_lambda_scaled_T18_R100.py   fabian_worker_unequalJ_T18_R100.py   combine_fabian_unequalJ_T18_R100.py

mkdir -p logs_unequalJ_T18_R100

Pilot:
sbatch --array=0-0%1 fabian_unequalJ_T18_R100_array.sbatch

Full run:
sbatch fabian_unequalJ_T18_R100_array.sbatch

Completion count:
find results_unequalJ_T18_R100 -maxdepth 2 -name DONE | wc -l

Expected:
1000

Combine:
~/AI_measurement_simulation_0817/.venv/bin/python   combine_fabian_unequalJ_T18_R100.py   --require-complete
